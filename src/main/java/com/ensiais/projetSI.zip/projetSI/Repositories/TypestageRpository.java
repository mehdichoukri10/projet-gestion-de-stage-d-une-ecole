package com.ensiais.projetSI.Repositories;

import com.ensiais.projetSI.Entities.Typestage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TypestageRpository extends JpaRepository<Typestage, Integer> {
}
