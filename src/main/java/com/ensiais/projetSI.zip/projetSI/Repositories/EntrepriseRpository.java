package com.ensiais.projetSI.Repositories;

import com.ensiais.projetSI.Entities.Entreprise;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntrepriseRpository extends JpaRepository<Entreprise, Long> {
}
