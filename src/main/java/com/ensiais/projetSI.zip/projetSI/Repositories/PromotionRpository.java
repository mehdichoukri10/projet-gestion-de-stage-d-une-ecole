package com.ensiais.projetSI.Repositories;

import com.ensiais.projetSI.Entities.Promotion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PromotionRpository extends JpaRepository<Promotion, Long> {
}
