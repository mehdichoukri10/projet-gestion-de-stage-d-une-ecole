package com.ensiais.projetSI.Repositories;

import com.ensiais.projetSI.Entities.Competence;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompetenceRpository extends JpaRepository<Competence,String> {
}
